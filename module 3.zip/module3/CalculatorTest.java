package module3;

import java.util.Scanner;

public class CalculatorTest {
	int a,b;
	Scanner sc = new Scanner(System.in);
	public void getNumber() {
		System.out.println("Enter First num :");
		a=sc.nextInt();
		System.out.println("Enter Second number :");
		b=sc.nextInt();
	}
	 public  void add() {
		 System.out.println(" The Addition of number is :"+(a+b));
	 }
	 public  void substraction() {
		 System.out.println(" The substraction of number is :"+(a-b));
	 }
	 public  void multiplication() {
		 System.out.println(" The multiplication of number is :"+(a*b));
	 }

	public static void main(String[] args) {
		CalculatorTest test=new CalculatorTest();
		test.getNumber();
		test.add();
		test.substraction();
		test.multiplication();
		

	}
}
