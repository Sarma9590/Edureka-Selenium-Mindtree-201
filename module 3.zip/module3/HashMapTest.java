package module3;

import java.util.HashMap;

public class HashMapTest {
	HashMap<String, Integer> hashMap=new HashMap<>();
	
	public HashMapTest() {
		hashMap.put("Robin", 1);
		hashMap.put("John", 2);
		hashMap.put("Mathew",3);
		hashMap.put("Joe",4);
		
	}
	public void displayHashMap() {
		System.out.println("The hashMap is ::"+hashMap);
	}
	public void displayKey() {
		System.out.println("The keys are ::"+hashMap.keySet());
	}
	public void displayValue() {
		System.out.println("The Values of each keys are:"+hashMap.values());
	}
	
	
	public static void main(String[] args) {
		HashMapTest hm=new HashMapTest();
		hm.displayHashMap();
		hm.displayKey();
		hm.displayValue();
	
	}

}
