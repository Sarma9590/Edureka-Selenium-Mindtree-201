package module4;

import org.junit.Assert;
import org.openqa.selenium.By;

public class ValidateFacebookPage extends BrowserDetails{
	
	public static void logintoApplication(String browserName) throws InterruptedException {
		getBrowser(browserName);
		driver.get("https://facebook.com");
	}
	public void validatePageContents() {
		String Actual=driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/div/div/div[1]/div/div")).getText();
		System.out.println("Actual text is ::"+Actual);
		Assert.assertTrue("Expected is Matched with Actual",Actual.contentEquals("Facebook helps you connect and share with the people in your life."));
		
		
		System.out.println("All text are Matched!!!!");
	}
	public String getTitleFacebook() {
		return driver.getTitle();
	}
	
	public static void main(String[] args) throws InterruptedException {
		ValidateFacebookPage validate=new ValidateFacebookPage();
		logintoApplication("Chrome");
		System.out.println("Title of page is ::"+ validate.getTitleFacebook());
		validate.validatePageContents();
	}
}
