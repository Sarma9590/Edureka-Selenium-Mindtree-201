package seleniumide;
 
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.fail;
 
import java.util.concurrent.TimeUnit;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
 
public class idetest {
 
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
 
  @BeforeClass(alwaysRun = true)
  public void setUp() throws Exception {
   
System.setProperty("webdriver.gecko.driver","C:\\TestLeaf\\eclipse-workspace\\assignments\\src\\driver\\geckodriver.exe");
    driver = new FirefoxDriver();
    baseUrl = "http://www.newtours.demoaut.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }
 
  @Test
  public void test() throws Exception {
    driver.get(baseUrl);
    driver.findElement(By.name("userName")).clear();
    driver.findElement(By.name("userName")).sendKeys("mercury");
    driver.findElement(By.name("password")).clear();
    driver.findElement(By.name("password")).sendKeys("mercury");
    driver.findElement(By.name("login")).click();
    try {
      assertEquals(driver.getTitle(), "Welcome: Mercury Tours");
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.linkText("SIGN-OFF")).click();
    try {
      assertEquals(driver.getTitle(), "Sign-on: Mercury Tours");
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.linkText("Home")).click();
  }
 
  @AfterClass(alwaysRun = true)
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }
}