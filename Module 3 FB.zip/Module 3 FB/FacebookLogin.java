package assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FacebookLogin {
	protected static WebDriver driver;
	String url = "https://www.facebook.com/";

	public FacebookLogin() throws InterruptedException {
		System.out.println("Launch Browser");
		System.setProperty("webdriver.chrome.driver", "D:\\Mercury Tours Final\\src\\main\\resources\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		System.out.println("Browser Launched successfully!!!");
	}

	public void FacebookLogin() throws InterruptedException {
		driver.findElement(By.cssSelector("#email")).sendKeys("UserName");
		driver.findElement(By.cssSelector("#pass")).sendKeys("Password");
		driver.findElement(By.cssSelector("#u_0_b")).click();
		System.out.println("Log in Successfully!!!");
	}

	public void quitBrowser() {
		driver.quit();
		System.out.println("Browser closed!!!");
	}

	public void PageNavigation(String command) {
		if (command.equalsIgnoreCase("back"))
			driver.navigate().back();
		else if (command.equalsIgnoreCase("refresh"))
			driver.navigate().refresh();
		else if(command.equalsIgnoreCase("next"))
			driver.navigate().forward();
		
		System.out.println(command + " Page Navigation occured!!!!");
	}

	public static void main(String[] args) throws InterruptedException {
		FacebookLogin login = new FacebookLogin();
		login.FacebookLogin();
		login.PageNavigation("back");
		login.quitBrowser();
	}

}
