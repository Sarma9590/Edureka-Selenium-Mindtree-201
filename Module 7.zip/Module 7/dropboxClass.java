package module7;


import org.testng.annotations.Test;

import module4.BrowserDetails;

public class dropboxClass extends BrowserDetails{

	@Test(invocationCount=5)
	public void getTitle() {
		BrowserDetails.getBrowser("Chrome");
		driver.get(" https://www.dropbox.com/");
		System.out.println("Page title is ::"+ driver.getTitle());
		driver.close();
	}
	
}
