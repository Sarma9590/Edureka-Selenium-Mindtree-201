package assignments;

import java.util.Scanner;

public class bidclc {

	private static Scanner sc;
	public static void main(String[] args) 
	{
		
		sc = new Scanner(System.in);
		
		System.out.print(" Please Enter Micheal Amount : ");
		float MAmount = sc.nextFloat();
		System.out.print(" Please Enter Bruce Amount : ");
		float BAmount = sc.nextFloat();	
			
		if(MAmount == BAmount)
	    {
			System.out.println("\n Both Amount are same");
		}
		else if(MAmount >= BAmount)
	    {
			System.out.println("\n Micheal won bid");
		}
		else if(MAmount <= BAmount)
	    {
			System.out.println("\n Bruce won bid");
		}
		
	}
}