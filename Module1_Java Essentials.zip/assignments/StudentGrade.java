package assignments;

import java.util.Scanner;

public class StudentGrade {
	private static Scanner sc;
	public static void main(String[] args) 
	{
		int English, Mathematics, Science, SScience; 
	    float total, Percentage;
		sc = new Scanner(System.in);
		
		System.out.print(" Please Enter the Four Subjects Marks : ");
		English = sc.nextInt();	
		Mathematics = sc.nextInt();	
		Science = sc.nextInt();	
		SScience = sc.nextInt();	
			
		
		total = English + Mathematics + Science + SScience ;
	    Percentage = (total / 400) * 100;
	 
	    System.out.println(" Total Marks =  " + total);
	    System.out.println(" Marks Percentage =  " + Percentage);
		
		if(Percentage >= 90)
	    {
			System.out.println("\n Excellent");
		}
		else if(Percentage >= 80)
	    {
			System.out.println("\n Very Good");
		}
		else if(Percentage >= 60)
	    {
			System.out.println("\n Good");
		}
		else if(Percentage >= 40)
	    {
			System.out.println("\n Average");
		}
		else 
	    {
			System.out.println("\n Poor");
		} 
	}
}